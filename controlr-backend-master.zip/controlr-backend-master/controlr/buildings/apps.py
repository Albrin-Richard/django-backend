from django.apps import AppConfig


class BuildingsConfig(AppConfig):
    name = 'buildings'
