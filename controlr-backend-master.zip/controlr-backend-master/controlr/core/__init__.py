default_app_config = 'controlr.core.apps.CoreConfig'
